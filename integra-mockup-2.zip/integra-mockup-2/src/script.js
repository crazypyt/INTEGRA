/* ==========================
   Integra — App Script
   ========================== */

/* ---------- Utilities ---------- */
const $ = sel => document.querySelector(sel);
const $$ = sel => document.querySelectorAll(sel);
const storage = {
  get: (k, def=null) => {
    try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : def; }
    catch { return def; }
  },
  set: (k, v) => localStorage.setItem(k, JSON.stringify(v)),
  del: (k) => localStorage.removeItem(k)
};

/* ---------- Tabs & Nav ---------- */
$$('.tab-btn').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    const target = btn.dataset.target;
    $$('.panel').forEach(p=>p.classList.toggle('active', p.id===target));
    $$('.tab-btn').forEach(b=>b.classList.toggle('active', b===btn));
    sfx.click();
  });
});
$$('.cta-row [data-nav]').forEach(b=>{
  b.addEventListener('click', ()=>{
    const target = b.dataset.nav;
    document.querySelector(`.tab-btn[data-target="${target}"]`).click();
  });
});

/* ---------- Dark Mode ---------- */
const darkToggle = $('#dark-toggle');
(function initDark(){
  const pref = storage.get('integraDark', null);
  if (pref === 'dark') document.documentElement.classList.add('dark');
  updateDarkIcon();
})();
darkToggle.addEventListener('click', ()=>{
  document.documentElement.classList.toggle('dark');
  storage.set('integraDark', document.documentElement.classList.contains('dark') ? 'dark' : 'light');
  updateDarkIcon();
  sfx.toggle();
});
function updateDarkIcon(){
  darkToggle.textContent = document.documentElement.classList.contains('dark') ? '☀️' : '🌙';
}

/* ---------- Sound Engine (WebAudio, no files) ---------- */
const AudioCtx = window.AudioContext || window.webkitAudioContext;
const audioCtx = new AudioCtx();
let musicEnabled = storage.get('musicEnabled', false);
let sfxEnabled   = storage.get('sfxEnabled', true);

const music = {
  playing: false,
  nodes: [],
  start(){
    if (music.playing || !musicEnabled) return;
    music.playing = true;
    const tempo = 96;
    let t = audioCtx.currentTime + .1;
    const master = audioCtx.createGain(); master.gain.value = 0.07; master.connect(audioCtx.destination);
    const scale = [0,2,4,7,9]; // major pentatonic
    const root = 261.63; // C4
    const loopLen = 16;
    const schedule = ()=>{
      for(let i=0;i<loopLen;i++){
        const degree = scale[(i%scale.length)];
        const osc = audioCtx.createOscillator();
        const g = audioCtx.createGain();
        osc.type='sine';
        osc.frequency.value = root * Math.pow(2, degree/12);
        g.gain.setValueAtTime(0.0001, t);
        g.gain.exponentialRampToValueAtTime(0.18, t+0.05);
        g.gain.exponentialRampToValueAtTime(0.0001, t+0.45);
        osc.connect(g).connect(master);
        osc.start(t);
        osc.stop(t+0.5);
        music.nodes.push(osc,g);
        t += 60/tempo;
      }
      if (music.playing) setTimeout(schedule, (loopLen*(60/tempo))*1000 - 50);
    };
    schedule();
  },
  stop(){
    music.playing = false;
    music.nodes.forEach(n=>{ try{ n.disconnect(); }catch{} });
    music.nodes = [];
  },
  toggle(){
    if (!musicEnabled){ return; }
    music.playing ? music.stop() : music.start();
  }
};

const sfx = {
  click(){ if(!sfxEnabled) return; tone(420, .03, 'square', 0.08); },
  correct(){ if(!sfxEnabled) return; tone(880,.07,'sine',0.14); tone(1175,.09,'sine',0.12, .05); },
  wrong(){ if(!sfxEnabled) return; tone(220,.14,'sawtooth',0.12); },
  flip(){ if(!sfxEnabled) return; tone(600,.04,'triangle',0.08); },
  toggle(){ if(!sfxEnabled) return; tone(500,.05,'square',0.08); }
};
function tone(freq, dur=0.1, type='sine', gain=0.12, delay=0){
  const t = audioCtx.currentTime + delay;
  const o = audioCtx.createOscillator();
  const g = audioCtx.createGain();
  o.type = type; o.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(gain, t+0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, t+dur);
  o.connect(g).connect(audioCtx.destination);
  o.start(t); o.stop(t+dur+0.02);
}

/* Music & SFX toggles */
const musicBtn = $('#music-toggle');
const sfxBtn   = $('#sfx-toggle');
function syncSoundButtons(){
  musicBtn.setAttribute('aria-pressed', String(musicEnabled));
  musicBtn.textContent = musicEnabled ? '🎵' : '🔇';
  sfxBtn.setAttribute('aria-pressed', String(sfxEnabled));
  sfxBtn.textContent = sfxEnabled ? '🔊' : '🔈';
}
syncSoundButtons();
musicBtn.addEventListener('click', ()=>{
  musicEnabled = !musicEnabled;
  storage.set('musicEnabled', musicEnabled);
  sfx.click();
  if (!musicEnabled) music.stop(); else music.start();
  syncSoundButtons();
});
sfxBtn.addEventListener('click', ()=>{
  sfxEnabled = !sfxEnabled;
  storage.set('sfxEnabled', sfxEnabled);
  sfx.toggle();
  syncSoundButtons();
});

/* ---------- Quote rotate ---------- */
const quotes = [
  "“Small progress each day adds up to big results.”",
  "“Mistakes are proof that you are trying.”",
  "“Math is not a spectator sport — practice!”",
  "“Focus on understanding, speed will follow.”"
];
let qi=0; const quoteEl = $('#quote');
setInterval(()=>{ qi=(qi+1)%quotes.length; quoteEl.textContent = quotes[qi]; }, 6000);

/* ---------- Achievements & Leaderboard preview ---------- */
function setBadges(){
  const b = $('#badges');
  b.innerHTML = '';
  const local = storage.get('integraBadges', ["Starter 🌱"]);
  local.forEach(x=>{
    const el = document.createElement('span');
    el.className='badge'; el.textContent = x;
    b.appendChild(el);
  });
}
setBadges();

function updateTopScore(val){
  const best = Math.max(storage.get('integraBest', 0), val||0);
  storage.set('integraBest', best);
  $('#top-score').textContent = best;
}
updateTopScore(storage.get('integraBest',0));

function loadLeaderboardPreview(){
  const data = (storage.get('integraLeaderboard', [])).slice(0,3);
  const list = $('#leaderboard-preview');
  list.innerHTML = '';
  if (data.length===0){ list.innerHTML = '<li>No scores yet.</li>'; return; }
  data.slice(0,3).forEach((r,i)=>{
    const li = document.createElement('li');
    li.textContent = `${i+1}. ${r.name} — ${r.score}`;
    list.appendChild(li);
  });
}
loadLeaderboardPreview();

/* ---------- Modal helpers ---------- */
const modal = $('#explain-modal');
const modalTitle = $('#modal-title');
const modalText = $('#modal-text');
$('#modal-close').addEventListener('click', closeModal);
$('#modal-ok').addEventListener('click', closeModal);
function openModal(title, text){
  modalTitle.textContent = title;
  modalText.textContent = text;
  modal.hidden = false;
}
function closeModal(){ modal.hidden = true; }

/* ---------- Confetti ---------- */
const confettiCanvas = $('#celebrate');
const ctx = confettiCanvas.getContext('2d');
function resizeCanvas(){ confettiCanvas.width = innerWidth; confettiCanvas.height = innerHeight; }
addEventListener('resize', resizeCanvas); resizeCanvas();

let confetti = [];
function spawnConfetti(n=80){
  for(let i=0;i<n;i++){
    confetti.push({
      x: Math.random()*confettiCanvas.width,
      y: -20,
      vx: (Math.random()-0.5)*2,
      vy: Math.random()*2+1,
      r: Math.random()*5+2,
      a: Math.random()*Math.PI*2
    });
  }
}
function drawConfetti(){
  ctx.clearRect(0,0,confettiCanvas.width,confettiCanvas.height);
  confetti.forEach(p=>{
    p.x += p.vx; p.y += p.vy; p.a += 0.05;
    ctx.save();
    ctx.translate(p.x,p.y);
    ctx.rotate(p.a);
    ctx.fillStyle = `hsl(${(p.x+p.y)%360},90%,60%)`;
    ctx.fillRect(-p.r,-p.r,p.r*2,p.r*2);
    ctx.restore();
  });
  confetti = confetti.filter(p=>p.y < confettiCanvas.height+40);
  requestAnimationFrame(drawConfetti);
}
drawConfetti();

/* ==========================
   QUIZ (Chapter 3 — 15 Qs)
   ========================== */
const quizData = [
  { q: "If f(x)=2x+3, find f(4).", c:["8","11","10","7"], a:1, hint:"Substitute x=4.", ex:"f(4)=2(4)+3=11." },
  { q: "Domain of f(x)=√(x−1)?", c:["x ≥ 1","x ≤ 1","x > 1","x < 1"], a:0, hint:"Inside root ≥ 0.", ex:"x−1≥0 ⇒ x≥1." },
  { q: "g(x)=x², h(x)=3x+1. Find (g∘h)(2).", c:["49","25","36","16"], a:0, hint:"Compute h(2) first.", ex:"h(2)=7; g(7)=49." },
  { q: "Inverse of f(x)=2x−5.", c:["(x+5)/2","2x+5","(x−5)/2","2x−5"], a:0, hint:"Swap x & y.", ex:"x=2y−5 ⇒ y=(x+5)/2." },
  { q: "f(x)=3x²−2x+1. Find f(0).", c:["1","0","-1","3"], a:0, hint:"Plug x=0.", ex:"3(0)−0+1=1." },
  { q: "Which is (f∘g)(x)?", c:["f(g(x))","g(f(x))","f(x)+g(x)","f(x)×g(x)"], a:0, hint:"Read ‘f of g’.", ex:"Apply g then f." },
  { q: "Range of f(x)=x² (x∈ℝ).", c:["ℝ","x ≥ 0","x ≤ 0","x > 0"], a:1, hint:"Square is nonnegative.", ex:"Minimum 0 at x=0." },
  { q: "Type of f(x)=5.", c:["Constant","Linear","Quadratic","Inverse"], a:0, hint:"No x term.", ex:"Always 5." },
  { q: "If f(x)=2x+1, f⁻¹(x)=?", c:["(x−1)/2","2x−1","(x+1)/2","1/(2x+1)"], a:0, hint:"Swap & solve.", ex:"y=2x+1 ⇒ x=(y−1)/2." },
  { q: "(f+g)(x) if f=x², g=3x.", c:["x²+3x","x²·3x","x³","3x²"], a:0, hint:"Just add.", ex:"(f+g)(x)=x²+3x." },
  { q: "If f(x)=1/x, domain?", c:["x≠0","x≥0","x>0","x∈ℝ"], a:0, hint:"Denominator ≠ 0.", ex:"x cannot be 0." },
  { q: "f(x)=√(4−x). Domain?", c:["x≤4","x≥4","x<4","x>4"], a:0, hint:"4−x ≥ 0.", ex:"x≤4." },
  { q: "If f(x)=x²−9, range (x∈ℝ)?", c:["y≥−9","y≥0","y>0","y≤0"], a:1, hint:"Min at x=0.", ex:"Min value 0−9? Wait, f(0)=-9? Nope. For x²−9, min is -9 at x=0 ⇒ range y≥−9." },
  { q: "Solve f(x)=3x+2. Find x if f(x)=11.", c:["x=3","x=4","x=2","x=5"], a:1, hint:"Set 3x+2=11.", ex:"3x=9 ⇒ x=3? Careful: 3x=9 ⇒ x=3 gives f(x)=11; correct ans is x=3 → (but choices?) Correction: answer index 0 should be 3. Update set accordingly." },
  { q: "If f(x)=|x−2|, range?", c:["y≥0","y>0","y≤0","all real"], a:0, hint:"Absolute value.", ex:"Output nonnegative." }
];
// Fix question 13 & 14 data properly:
quizData[12] = { q:"If f(x)=x²−9, range (x∈ℝ)?", c:["y≥−9","y≥0","y>0","y≤0"], a:0, hint:"Minimum occurs at vertex.", ex:"x²≥0 ⇒ x²−9 ≥ −9; so y≥−9." };
quizData[13] = { q:"For f(x)=3x+2, solve f(x)=11.", c:["x=3","x=4","x=2","x=5"], a:0, hint:"Set 3x+2=11.", ex:"3x=9 ⇒ x=3." };

// DOM
const qQuestion  = $('#quiz-question');
const qChoices   = $('#quiz-choices');
const qHint      = $('#quiz-hint');
const qTimerEl   = $('#quiz-timer');
const qProgress  = $('#quiz-progress');
const qScoreEl   = $('#quiz-score');
const qStartBtn  = $('#quiz-start');
const qSubmitBtn = $('#quiz-submit');
const qNextBtn   = $('#quiz-next');

let qIndex=0, qScore=0, qSelected=null, qTimer=null, qTime=30;

function quizReset(){
  qIndex=0; qScore=0; qSelected=null; qTime=30;
  qScoreEl.textContent = qScore;
  qProgress.textContent = `1/${quizData.length}`;
  qQuestion.textContent = "Press Start to begin";
  qChoices.innerHTML = '';
  qHint.hidden = true;
  qSubmitBtn.hidden = true;
  qNextBtn.hidden = true;
}
quizReset();

qStartBtn.addEventListener('click', ()=>{
  sfx.click();
  loadQuizQ();
});
qSubmitBtn.addEventListener('click', submitQuizAnswer);
qNextBtn.addEventListener('click', nextQuizQ);

function loadQuizQ(){
  clearInterval(qTimer);
  qTime=30; qTimerEl.textContent = qTime;
  qTimer = setInterval(()=>{
    qTime--; qTimerEl.textContent=qTime;
    if (qTime<=0){ clearInterval(qTimer); autoQuizSubmit(); }
  },1000);

  const q = quizData[qIndex];
  qQuestion.textContent = q.q;
  qProgress.textContent = `${qIndex+1}/${quizData.length}`;
  qHint.textContent = `Hint: ${q.hint}`;
  qHint.hidden = false;

  qChoices.innerHTML = '';
  q.c.forEach((choice, i)=>{
    const li = document.createElement('li');
    li.textContent = choice;
    li.addEventListener('click', ()=>{
      [...qChoices.children].forEach(x=>x.classList.remove('selected'));
      li.classList.add('selected');
      qSelected=i; sfx.click();
      qSubmitBtn.hidden = false;
    });
    qChoices.appendChild(li);
  });
}

function submitQuizAnswer(){
  if (qSelected===null) return;
  clearInterval(qTimer);
  const q = quizData[qIndex];
  const correct = qSelected===q.a;
  [...qChoices.children].forEach((li,i)=>{
    li.classList.remove('selected');
    if (i===q.a) li.classList.add('correct'); else if (i===qSelected) li.classList.add('wrong');
    li.style.pointerEvents='none';
  });
  if (correct){
    qScore++; qScoreEl.textContent = qScore;
    sfx.correct();
    spawnConfetti(80);
  }else{
    sfx.wrong();
    openModal("Keep going 💪", `Not quite. ${q.ex}`);
  }
  qSubmitBtn.hidden = true;
  qNextBtn.hidden = false;
}

function autoQuizSubmit(){
  const q = quizData[qIndex];
  [...qChoices.children].forEach((li,i)=>{
    if (i===q.a) li.classList.add('correct');
    li.style.pointerEvents='none';
  });
  sfx.wrong();
  openModal("Time's up ⏳", q.ex);
  qSubmitBtn.hidden = true;
  qNextBtn.hidden = false;
}

function nextQuizQ(){
  qIndex++;
  if (qIndex>=quizData.length){
    // end
    const msg = `You scored ${qScore}/${quizData.length}.`;
    openModal("Quiz Completed 🎉", msg);
    updateTopScore(qScore);
    pushPendingScore(qScore);
    const badges = storage.get('integraBadges', []);
    if (qScore===quizData.length && !badges.includes("Perfect Quiz 🏅")){
      badges.push("Perfect Quiz 🏅"); storage.set('integraBadges', badges); setBadges();
    }
    quizReset();
    return;
  }
  qSelected=null; loadQuizQ();
}

/* ==========================
   ARCADE
   ========================== */
const arcadeQ = quizData; // reuse
const aTimerEl = $('#arcade-timer');
const aScoreEl = $('#arcade-score');
const aStreakEl= $('#arcade-streak');
const aQuestion= $('#arcade-question');
const aHintEl  = $('#arcade-hint');
const aChoices = $('#arcade-choices');
const aStart   = $('#arcade-start');
const aSkip    = $('#arcade-skip');

let aTime=60, aTimer, aIndex=0, aScore=0, aStreak=0, aSelected=null;
aStart.addEventListener('click', startArcade);
aSkip.addEventListener('click', ()=>{ sfx.click(); nextArcadeQ(); });

function startArcade(){
  sfx.click();
  aTime=60; aScore=0; aStreak=0; aIndex=0;
  aScoreEl.textContent=aScore; aStreakEl.textContent=aStreak; aTimerEl.textContent=aTime;
  clearInterval(aTimer);
  aTimer=setInterval(()=>{ aTime--; aTimerEl.textContent=aTime; if(aTime<=0){ endArcade(); } },1000);
  loadArcadeQ();
}
function loadArcadeQ(){
  const q = arcadeQ[aIndex % arcadeQ.length];
  aQuestion.textContent = q.q;
  aHintEl.textContent = `Hint: ${q.hint}`;
  aHintEl.hidden=false;
  aChoices.innerHTML='';
  q.c.forEach((choice,i)=>{
    const li=document.createElement('li');
    li.textContent=choice;
    li.addEventListener('click', ()=>{
      if (i===q.a){
        aScore++; aStreak++; sfx.correct(); spawnConfetti(30);
      }else{
        aStreak=0; sfx.wrong();
      }
      aScoreEl.textContent=aScore; aStreakEl.textContent=aStreak;
      nextArcadeQ();
    });
    aChoices.appendChild(li);
  });
}
function nextArcadeQ(){
  aIndex++; loadArcadeQ();
}
function endArcade(){
  clearInterval(aTimer);
  openModal("Arcade over 🕹️", `Score: ${aScore}, best streak: ${aStreak}.`);
  updateTopScore(aScore);
  pushPendingScore(aScore);
}

/* ==========================
   DAILY MISSION
   ========================== */
const dailyDateEl = $('#daily-date');
const dailyDescEl = $('#daily-desc');
const dailyStatus = $('#daily-status');
const dQEl = $('#daily-question');
const dChoicesEl = $('#daily-choices');
const dHintEl = $('#daily-hint');
const dStartBtn = $('#daily-start');
const dSubmitBtn= $('#daily-submit');

function initDaily(){
  const today = new Date().toISOString().slice(0,10);
  dailyDateEl.textContent = today;
  dailyDescEl.textContent = "Answer the question correctly (1 try).";
  const q = quizData[Math.floor(Math.random()*quizData.length)];
  dQEl.textContent = q.q;
  dHintEl.textContent = `Hint: ${q.hint}`;
  dChoicesEl.innerHTML='';
  q.c.forEach((c,i)=>{
    const li=document.createElement('li'); li.textContent=c;
    li.addEventListener('click', ()=>{
      [...dChoicesEl.children].forEach(x=>x.classList.remove('selected'));
      li.classList.add('selected'); li.dataset.index=i;
      sfx.click(); dSubmitBtn.style.display='inline-block';
    });
    dChoicesEl.appendChild(li);
  });
  dStartBtn.onclick = ()=>{
    sfx.click();
    dailyStatus.textContent = "In progress…";
    dHintEl.hidden=false;
  };
  dSubmitBtn.onclick = ()=>{
    const sel = [...dChoicesEl.children].find(x=>x.classList.contains('selected'));
    if (!sel) return;
    if (+sel.dataset.index===q.a){
      sfx.correct(); spawnConfetti(60);
      dailyStatus.textContent = "Completed ✅";
      const badges = storage.get('integraBadges', []);
      if (!badges.includes("Daily Hero 🌞")){
        badges.push("Daily Hero 🌞"); storage.set('integraBadges', badges); setBadges();
      }
    }else{
      sfx.wrong();
      dailyStatus.textContent = "Failed ❌";
      openModal("Explanation", q.ex);
    }
  };
}
initDaily();

/* ==========================
   Leaderboard
   ========================== */
const lbList = $('#leaderboard-list');
const lbForm = $('#submit-score-form');
const lbName = $('#player-name');
const lbScore= $('#player-score');
function renderLeaderboard(){
  const data = storage.get('integraLeaderboard', []);
  lbList.innerHTML='';
  if (data.length===0){ lbList.innerHTML='<li>No scores yet.</li>'; return; }
  data.slice(0,20).forEach((r,i)=>{
    const li=document.createElement('li');
    if (i===0) li.classList.add('top1'); else if (i===1) li.classList.add('top2'); else if (i===2) li.classList.add('top3');
    li.innerHTML = `<span>${i+1}. ${r.name}</span><span>${r.score}</span>`;
    lbList.appendChild(li);
  });
}
renderLeaderboard();

function pushPendingScore(score){
  storage.set('pendingScore', score);
  lbScore.value = score;
  $('#player-name').focus();
}
lbForm.addEventListener('submit', (e)=>{
  e.preventDefault();
  sfx.click();
  const name = (lbName.value||'Player').slice(0,20);
  const score = +lbScore.value || storage.get('pendingScore', 0);
  if (!score){ openModal("Oops", "No score to submit yet."); return; }
  const data = storage.get('integraLeaderboard', []);
  data.push({name, score});
  data.sort((a,b)=>b.score-a.score);
  storage.set('integraLeaderboard', data);
  storage.del('pendingScore');
  lbName.value=''; lbScore.value='';
  renderLeaderboard(); loadLeaderboardPreview();
  openModal("Submitted 🎉", "Your score has been added.");
});

/* ==========================
   Games — Memory Match
   ========================== */
const memGrid = $('#memory-grid');
const memStart = $('#memory-start');
const memMoves = $('#memory-moves');
const memPairs = $('#memory-pairs');

const icons = ["🍎","🍊","🍉","🍇","🍒","🍓","🥝","🍍"];
let memDeck=[], memFirst=null, memLock=false, pairs=0, moves=0;

memStart.addEventListener('click', startMemory);
function startMemory(){
  sfx.click();
  const deck = [...icons, ...icons]
    .sort(()=>Math.random()-0.5)
    .map((ico,i)=>({id:i, ico, matched:false}));
  memDeck = deck; memFirst=null; memLock=false; pairs=0; moves=0;
  memMoves.textContent = moves; memPairs.textContent = `${pairs}/8`;
  renderMemory();
}
function renderMemory(){
  memGrid.innerHTML='';
  memDeck.forEach((card)=>{
    const item = document.createElement('div');
    item.className='card-tile';
    item.setAttribute('data-id', card.id);
    item.innerHTML = `
      <div class="tile-face tile-back">?</div>
      <div class="tile-face tile-front">${card.ico}</div>
    `;
    if (card.matched) item.classList.add('flip');
    item.addEventListener('click', ()=>flipCard(card.id, item));
    memGrid.appendChild(item);
  });
}
function flipCard(id, el){
  if (memLock) return;
  const card = memDeck.find(c=>c.id===id);
  if (!card || card.matched) return;
  sfx.flip();
  el.classList.add('flip');

  if (!memFirst){
    memFirst = {id, el, card};
  } else {
    moves++; memMoves.textContent=moves;
    const first = memFirst; memFirst=null; memLock=true;
    setTimeout(()=>{
      if (first.card.ico === card.ico){
        first.card.matched = true; card.matched = true;
        pairs++; memPairs.textContent = `${pairs}/8`;
        sfx.correct(); spawnConfetti(20);
        memLock=false;
        if (pairs===8) openModal("GG 🎉", `You did it in ${moves} moves!`);
      } else {
        first.el.classList.remove('flip'); el.classList.remove('flip');
        sfx.wrong();
        memLock=false;
      }
    }, 450);
  }
}

/* ==========================
   Games — Math Rush
   ========================== */
const rushStart = $('#rush-start');
const rushTimeEl = $('#rush-time');
const rushScoreEl= $('#rush-score');
const rushStreakEl=$('#rush-streak');
const rushQ = $('#rush-question');
const rushInput = $('#rush-input');

let rTimer=null, rTime=45, rScore=0, rStreak=0, rAns=0;

rushStart.addEventListener('click', startRush);
rushInput.addEventListener('keydown', (e)=>{
  if (e.key==='Enter'){ checkRush(); }
});

function startRush(){
  sfx.click();
  rTime=45; rScore=0; rStreak=0;
  rushTimeEl.textContent=rTime; rushScoreEl.textContent=rScore; rushStreakEl.textContent=rStreak;
  rushInput.value=''; rushInput.disabled=false; rushInput.focus();
  clearInterval(rTimer);
  rTimer=setInterval(()=>{ rTime--; rushTimeEl.textContent=rTime; if(rTime<=0) endRush(); },1000);
  nextRushQ();
}
function nextRushQ(){
  const ops = ['+','−','×','÷'];
  const op = ops[Math.floor(Math.random()*ops.length)];
  let a = Math.floor(Math.random()*18)+2;
  let b = Math.floor(Math.random()*18)+2;
  if (op==='÷'){ a = a*b; } // make divisible
  const disp = `${a} ${op} ${b}`;
  rAns = (op==='+')? a+b : (op==='−')? a-b : (op==='×')? a*b : a/b;
  rushQ.textContent = disp;
}
function checkRush(){
  const v = Number(rushInput.value);
  if (Number.isNaN(v)) return;
  const ok = Math.abs(v - rAns) < 1e-6;
  if (ok){
    rScore++; rStreak++; sfx.correct(); spawnConfetti(10);
  }else{
    rStreak=0; sfx.wrong();
  }
  rushScoreEl.textContent=rScore; rushStreakEl.textContent=rStreak;
  rushInput.value=''; nextRushQ();
}
function endRush(){
  clearInterval(rTimer);
  rushInput.disabled=true;
  openModal("Rush Over", `Score: ${rScore} (streak ${rStreak}).`);
  updateTopScore(rScore);
  pushPendingScore(rScore);
}

/* ==========================
   Games — Reaction Time
   ========================== */
const reactStart = $('#reaction-start');
const reactBest  = $('#reaction-best');
const reactPad   = $('#reaction-pad');
const reactStatus= $('#reaction-status');

let trial=0, best=Infinity, waiting=false, green=false, waitTO=null, startT=0;

reactStart.addEventListener('click', startReaction);
reactPad.addEventListener('click', onReactClick);
reactPad.addEventListener('keydown', e=>{ if(e.key==='Enter'||e.key===' ') onReactClick(); });

function startReaction(){
  sfx.click();
  trial=0; best=Infinity; updateBestLabel();
  nextReaction();
}
function nextReaction(){
  trial++;
  waiting=true; green=false; reactPad.classList.add('wait'); reactPad.classList.remove('go');
  reactStatus.textContent = "Wait for green…";
  const delay = 1000 + Math.random()*2000;
  clearTimeout(waitTO);
  waitTO = setTimeout(()=>{
    green=true; waiting=false; reactPad.classList.remove('wait'); reactPad.classList.add('go');
    reactStatus.textContent = "GO! Click now!";
    startT = performance.now();
  }, delay);
}
function onReactClick(){
  if (!trial){ sfx.click(); return; }
  if (waiting && !green){
    sfx.wrong(); reactStatus.textContent = "Too early! ⛔";
    return;
  }
  if (green){
    const t = performance.now() - startT;
    sfx.correct(); spawnConfetti(8);
    if (t<best) best=t;
    updateBestLabel(t);
    if (trial<5) nextReaction(); else {
      reactPad.classList.remove('go'); reactStatus.textContent = "Done! Press Start for new set.";
      openModal("Reaction Results", `Best time: ${best.toFixed(0)} ms`);
      updateTopScore(Math.max(storage.get('integraBest',0), Math.round(500 - Math.min(best,500)/5)));
    }
  }
}
function updateBestLabel(cur){
  reactBest.textContent = isFinite(best) ? `${best.toFixed(0)} ms` : '—';
}

/* ---------- Help ---------- */
$('#help-btn').addEventListener('click', ()=>{
  sfx.click();
  openModal("Tips & Shortcuts ✨",
    "• Toggle music (🎵) & SFX (🔊) on the top-right.\n" +
    "• Dark mode with the moon button.\n" +
    "• Leaderboard saves locally on this device.\n" +
    "• Use Games to warm-up your focus before quizzes!");
});
